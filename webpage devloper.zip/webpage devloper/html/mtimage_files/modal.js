(function ($) {

    'use strict';

    $(function () {

        jQuery(document).on('click', '.add-to-cart', function (e) {

            e.preventDefault();

            let element = jQuery(this);

            let elementHtml = element.html();

            let parent = element.data('product-id');

            let variation = jQuery('[data-product-id-variation="' + parent + '"]');

            let variation_id = variation.children("option:selected").val();

            let quantity = jQuery('[data-product-id-quantity="' + parent + '"]');

            quantity = quantity.children("option:selected").val();

            let data = {
                "product_id": parent,
                "variation_id": variation_id,
                "quantity": quantity,
                "action": "climber_portal_add_to_cart"
            };

            element.html('<i class="fas fa-cog fa-spin fa-2x fa-fw"></i><span class="sr-only">Adding To Cart...</span>');

            // $.post('/wp-json/post/v1/cart/', data, success, 'json');
            console.log(data);
            console.log(climberPortal.adminAjax);
            $.post(climberPortal.adminAjax, data)
                .done(function (response) {
                    console.log(response);
                    if (response && response.hasOwnProperty('error')) {
                        let errorContainer = document.getElementById('wc-error-messages');
                        response.error.forEach(function (error) {
                            $('#wc-error-messages').append('<div class="alert alert-danger alert-dismissible fade show" role="alert"></button>' + error + '</div>');
                        });
                        element.html(elementHtml);
                    }

                    if (response && !response.hasOwnProperty('error')) {
                        element.removeClass('btn-primary');
                        element.addClass('btn-success');
                        element.html("Item In Cart");
                        $("#purchase-gear-cart-count").html(response.cart_count);
                        $(".aa-current-cart-count").html(response.cart_count);
                    }
                })
                .fail(function (response) {
                    console.log(response);
                });

        });
    });
    

})(jQuery);