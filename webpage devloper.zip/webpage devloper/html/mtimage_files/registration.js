(function ($) {
    'use strict';

    $(() => {

        $("#primaryDeparture").on("change", function (element) {
            document.getElementById('primaryDepartureHidden').value = element.currentTarget.value
        })

        $("#secondaryDeparture").on("change", function (element) {
            document.getElementById('secondaryDepartureHidden').value = element.currentTarget.value
        })

        $(".tripOptionInput").on("click", function (element) {
            if (element.currentTarget.checked) {
                $('<input>').attr({
                    type: 'hidden',
                    id: `toidhidden${element.currentTarget.id}`,
                    name: 'registration[trip_option][]',
                    value: element.currentTarget.value
                }).appendTo('#registration');
            } else {
                $(`#toidhidden${element.currentTarget.id}`).remove()
            }
        })

        /**
         * Validation Rules
         */
        $.validator.addMethod("minDate", function (value, element) {
            var now = new Date();
            var myDate = new Date(value);
            return this.optional(element) || myDate > now;
        });

        $.validator.addMethod('dateFormat', function (value, element) {
            if (value) {
                var regEx = /^\d{4}-\d{2}-\d{2}$/;
                if (!value.match(regEx)) return false;  // Invalid format
                var d = new Date(value);
                if (!d.getTime() && d.getTime() !== 0) return false; // Invalid date
                return d.toISOString().slice(0, 10) === value;
            }
            return true;
        }, 'Please enter a date in the format yyyy-mm-dd.');

        /**
         * Add jQuery Validation
         */
        jQuery('#registration').validate({
            errorElement: "div",
            validClass: "is-valid",
            // debug: true,
            rules: {
                "client[birthday]": {
                    required: true,
                    date: true,
                },
                "client[emergency_contact_phone]": {
                    minlength: 7
                },
                "client_billing[cc_cvv]": {
                    minlength: 3
                },
                "client[phone]": {
                    minlength: 7
                },
                confirm_email: {
                    equalTo: "#email"
                },
                "registration[departure_1]": {
                    dateFormat: true,
                    minDate: true
                },
                "registration[departure_2]": {
                    dateFormat: true,
                    minDate: true
                },
                "client_billing[cc_expires_month]": {
                    min: 1,
                    max: 12
                },
                "client_billing[cc_number]": {
                    creditcard: true
                },
                'client_billing[cc_expires_year]': {
                    min: 2020,
                    max: 2030
                },
                'client_billing[cc_cvv]': {
                    min: 0,
                    max: 9999
                }
            },
            messages: {
                "client[emergency_contact_phone]": {
                    minlength: "Please enter 10 or more numbers."
                },
                "client[phone]": {
                    minlength: "Please enter 10 or more numbers."
                },
                "client_billing[cc_cvv]": {
                    minlength: "Please enter 3 or more digits."
                },
                "client[email]": {
                    equalTo: "Email does not match."
                },
                confirm_email: {
                    equalTo: "Email does not match."
                },
                "registration[departure_1]": {
                    dateFormat: "Please enter a date in the format YYYY-MM-DD.",
                    minDate: "Please enter a date in the future",
                },
                "registration[departure_2]": {
                    dateFormat: "Please enter a date in the format YYYY-MM-DD.",
                    minDate: "Please enter a date in the future",
                }
            },
            errorPlacement: function (error, element) {
                // console.log(error);
                // console.log(element);
                // console.log($(element).parent());
                // error.insertBefore(element);
                if ($(element).siblings().length !== 0) {
                    error.insertAfter($(element).siblings());
                } else {
                    error.insertAfter(element);
                }
            }
        });

        jQuery("#primaryDeparture").datepicker({
            minDate: new Date(),
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true,
            yearRange: '2021:2030'
        });

        jQuery("#primaryDeparture").on("change", function (element) {
            $("#submitAnonRegistration").attr('disabled', false)
            $("#submitAnonRegistration").removeClass('disabled-link')
            if (element.target.value.length == 0) {
                $("#submitAnonRegistration").attr('disabled', true)
                $("#submitAnonRegistration").addClass('disabled-link')
            }
            jQuery("#registrationDepartureDates").valid();
        })

        jQuery("#secondaryDeparture").datepicker({
            minDate: new Date(),
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true,
            yearRange: '2021:2030'
        })

        jQuery("#secondaryDeparture").on("change", function (element) {
            jQuery("#registrationDepartureDates").valid();
        })

        jQuery("#registrationDepartureDates").validate({
            errorElement: "div",
            validClass: "is-valid",
            rules: {
                "registration[departure_1]": {
                    dateFormat: true,
                    minDate: true
                },
                "registration[departure_2]": {
                    dateFormat: true,
                    minDate: true
                },
            },
            messages: {
                "registration[departure_1]": {
                    dateFormat: "Please enter a date in the format YYYY-MM-DD.",
                    minDate: "Please enter a date in the future",
                },
                "registration[departure_2]": {
                    dateFormat: "Please enter a date in the format YYYY-MM-DD.",
                    minDate: "Please enter a date in the future",
                }
            },
            errorPlacement: function (error, element) {
                $(element).removeClass('error');
                if ($(element).siblings().length !== 0) {
                    error.insertAfter($(element).siblings());
                } else {
                    error.insertAfter(element);
                }
            },
            showErrors: function (errorMap, errorList) {
                // errorList[0].element; // <- index "0" is the first element with an error

                if (errorList.length > 0) {
                    document.getElementById('registrationDepartureDates').scrollIntoView(true);
                }

                this.defaultShowErrors(); // keep error messages next to each input element   
            }
        })

        function getUrlVars() {
            var vars = {};
            var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function (m, key, value) {
                vars[key] = value;
            });
            return vars;
        }

        let confirmPanelJ = jQuery('.confirm-panel');
        jQuery.each(confirmPanelJ, function (index) {
            let confirm_id = getUrlVars()['departure_uuid'] + "_" + jQuery(this).attr('id');
            if (sessionStorage.getItem(confirm_id) && sessionStorage.getItem(confirm_id) == true) {
                jQuery(this).prop('checked', true);
            }
        });

        let confirmSection = $("input.fieldset-confirm-toggle");
        $.each(confirmSection, function (index) {
            if (confirmSection[index].checked) {
                const fieldsetSection = confirmSection[index].dataset.disable
                jQuery(`fieldset#${fieldsetSection} :input`).each(function (index, element) {
                    let attribute = document.createAttribute("disabled")
                    attribute.value = "true";
                    element.setAttributeNode(attribute);
                })
            }
        })

        jQuery('.confirm-panel').on('click', function () {
            let element_id = getUrlVars()['departure_uuid'] + "_" + jQuery(this).attr('id'),
                value = jQuery(this).is(":checked") ? 1 : 0;
            sessionStorage.setItem(element_id, value);
        });

        jQuery("#birthday").on("change", function (element) {
            let birthdate = new Date(element.currentTarget.value)
            var diff_ms = Date.now() - birthdate.getTime();
            var age_dt = new Date(diff_ms);
        })

        jQuery("#billingSameMailing").on("click", function () {
            jQuery("#billingAddressFields").toggle();
        });

        jQuery("input.how_learn_about_us").on("change", function (element) {
            if (jQuery(this).attr('id') == 'other') {
                jQuery("#how_learn_about_us_other").removeClass("hide");
                jQuery("#how_learn_about_us_other").removeAttr('disabled');
                jQuery("#how_learn_about_us_other").attr('required', 'true');

            } else {
                jQuery("#how_learn_about_us_other").attr('disabled', 'true');
                jQuery("#how_learn_about_us_other").attr('required', 'false');
                jQuery("#how_learn_about_us_other").addClass("hide");
            }
        })

        jQuery("input.problems").on("change", function (element) {
            jQuery("input.problems").each(function (index, element) {
                if (jQuery(element).is(":checked")) {
                    jQuery("#medical_history_container").removeClass("hide");
                    jQuery("#medical_history").attr('required', 'true');
                    jQuery("#problemsNone").prop('checked', false).removeAttr("required")
                    return false;
                }

                jQuery("#medical_history_container").addClass("hide");
                jQuery("#medical_history").text("").removeAttr('required').attr('disabled')
                let noProbCheck = document.getElementById("problemsNone")
                noProbCheck.removeAttribute('disabled')
                noProbCheck.setAttribute('required', 'true');
            })
        });

        jQuery("#problemsNone").on("change", function (element) {
            if (jQuery(this).is(":checked")) {
                jQuery("input.problems").each(function (index, element) {
                    if (jQuery(element).is(":checked")) {
                        jQuery(element).prop('checked', false)
                    }
                })
                jQuery("#medical_history").text("").removeAttr('required').attr('disabled')
                jQuery("#medical_history_container").addClass("hide");
            }
        })

        jQuery("input.coldInjury").on("change", function (element) {
            if (jQuery(this).attr('value') == '1') {
                jQuery("#coldInjuryDescriptionContainer").removeClass("hide")
            } else {
                jQuery("#coldInjuryDescriptionContainer").addClass("hide")
            }
        })

        jQuery("input.preexisting").on("change", function (element) {
            if (jQuery(this).attr('value') == '1') {
                jQuery("#preexisting_conditions_description_container").removeClass("hide")
            } else {
                jQuery("#preexisting_conditions_description_container").addClass("hide")
            }
        })

        jQuery("input.altitudeIllness").on("change", function (element) {
            if (jQuery(this).attr('value') == '1') {
                jQuery("#altitude_illness_description_container").removeClass("hide")
            } else {
                jQuery("#altitude_illness_description_container").addClass("hide")

            }
        })

        jQuery("input.dietary_answer").on("change", function (element) {
            if (jQuery(this).attr('id') == "dietary_answer_other") {
                jQuery("#dietary_answer_other_input").removeClass("hide");
                jQuery("#dietary_answer_other_input").removeAttr("disabled")
            } else {
                jQuery("#dietary_answer_other_input").addClass("hide");
                jQuery("#dietary_answer_other_input").attr("disabled", "true")
            }
        });

        jQuery("input.fieldset-confirm-toggle").on("click", function (element) {
            let fieldset_name = jQuery(this).data('disable');
            let fieldset = document.getElementById(`${fieldset_name}`);
            if (jQuery(this).is(":checked")) {
                jQuery(`fieldset#${fieldset_name} :input`).each(function (index, element) {
                    let attribute = document.createAttribute("disabled")
                    attribute.value = "true";
                    element.setAttributeNode(attribute);
                })
            } else {
                jQuery(`fieldset#${fieldset_name} :input`).each(function (index, element) {
                    element.removeAttribute("disabled");
                })
                // fieldset.removeAttribute("disabled");
            }
        })

        jQuery('.registration-next').on('click', function () {
            $('#registrationDepartureDates').valid()
            let navElements = $('.aa-registration-tab');
            $.each(navElements, function (index, el) {
                if (el.classList.contains('active')) {
                    let activeIndex = index;
                    let currentTab = navElements[index];
                    let nextTab = navElements[++index];
                    for (let x = ++activeIndex; x < navElements.length; x++) {
                        if (navElements[x].dataset.required == "true") {
                            nextTab = navElements[x];
                            break;
                        }
                    }

                    if ($('#registration').valid()) {
                        
                        let scrollTo = document.getElementById('registration');

                        currentTab.classList.add('valid');
                        currentTab.classList.remove('invalid');
                        nextTab.classList.remove('disabled');
                        nextTab.click();

                        scrollTo.scrollIntoView(true);
                        return false;
                    }

                    return false;
                }
            });
        });

        jQuery('.registration-back').on('click', function () {
            let navElements = $('.aa-registration-tab');
            $.each(navElements, function (index, el) {
                if (el.classList.contains('active')) {
                    let currentIndex = index,
                        previousTab = navElements[--index];
                    for (let x = --currentIndex; x >= 0; x--) {
                        if (navElements[x].dataset.required) {
                            previousTab = navElements[x];
                            break;
                        }
                    }

                    previousTab.click();
                    document.getElementById('registration').scrollIntoView(true);
                    return false;
                }
            })
        });

        $('a.aa-registration-tab[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            let fieldSetToValidate = e.relatedTarget.dataset.fieldset;
            $(fieldSetToValidate).find('[required]').each(function (index, field) {
                if (!field.disabled && field.required && field.value == '') {
                    if (field.classList.contains('is-valid')) {
                        field.classList.replace('is-valid', 'is-invalid');
                    } else {
                        field.classList.add('is-invalid');
                    }
                    
                    if (e.relatedTarget.classList.contains('valid')) {
                        e.relatedTarget.classList.replace('valid', 'invalid');
                    } else {
                        e.relatedTarget.classList.add('invalid');
                    }

                    return false;
                }
            });
        });

        $('fieldset.validate-section input[required]').on('change', function (e) {
            if (e.target.classList.contains('is-invalid') && e.target.value !== '') {
                e.target.classList.replace('is-invalid', 'is-valid');
            }
        });

        // $('#climberPortalSubmitRegistration').on('click', function (event) {

        //     event.preventDefault();

        //     let validForm = true;

        //     $('.aa-registration-tab').each(function (index, element) {
        //         if (element.classList.contains('invalid')) {
        //             document.getElementById(element.id).click();
        //             console.log("Before")
        //             $('#registration').valid();
        //             $('#registrationDepartureDates').valid();
        //             console.log("After")
        //             validForm = false;
        //             return false;
        //         }
        //     });

        //     if (validForm == true) {

        //         let form = document.getElementById('registration'),
        //             registrationForm = new FormData(form);
                
        //         console.log("Submitting...");
        //         $(document.body).append("<div id='submitting'></div>")

        //         $.ajax({
        //             type: 'POST',
        //             url: aaAjax.url,
        //             data: registrationForm,
        //             processData: false,
        //             contentType: false,
        //         }).done((response) => {
        //             console.log(response);
        //             if (response.success && response.redirect) {
        //                 window.location.replace(response.redirect);
        //             }
        //             $(document.body).remove("#submitting");
        //         }).fail((response) => {
        //             console.log("Error: ");
        //             console.log(response);
        //             $(document.body).remove("#submitting");
        //         });
        //     }
        // });

        $('#updateTermsConditions').on('submit', function (element) {
            element.preventDefault();
            let form = document.getElementById('updateTermsConditions'),
                registrationForm = new FormData(form);
            console.log("Submitting...");
            $(document.body).append("<div id='submitting'></div>")

            $.ajax({
                type: 'POST',
                url: aaAjax.url,
                data: registrationForm,
                processData: false,
                contentType: false,
            }).done((response) => {
                if (response.success && response.redirect) {
                    window.location.replace(response.redirect);
                }
                $(document.body).remove("#submitting");
            }).fail((response) => {
                console.log("Error: ");
                console.log(response);
                $(document.body).remove("#submitting");

            });
        })

        $('#submitAnonRegistration').on('click', function () {
            let validForm = true;

            $('.aa-registration-tab').each(function (index, element) {
                if (element.classList.contains('invalid')) {
                    document.getElementById(element.id).click();
                    $('#registration').validate();
                    validForm = false;
                    return false;
                }
            });

            if (!$('#registrationDepartureDates').valid()) {
                validForm = false;
            }

            if (validForm) {

                let form = document.getElementById('registration'),
                    registrationForm = new FormData(form);

                $(document.body).append("<div id='submitting'></div>")

                $.ajax({
                    type: 'POST',
                    url: anonRegistrationUrl,
                    data: registrationForm,
                    processData: false,
                    contentType: false,
                }).done((response) => {
                    if (response.status == 200 && response.redirect) {
                        window.location.replace(response.redirect);
                    }
                    document.querySelector("#submitting").remove();
                }).fail((response) => {
                    console.log("Error: ", response);
                    document.querySelector("#submitting").remove();
                    if (response.status === 422 && response.responseJSON.errors.length !== 0) {
                        response.responseJSON.errors.forEach((error) => {
                            for (const [key, value] of Object.entries(error)) {
                                value.forEach((displayError) => {
                                    $("#registrationErrors").append(`<div class="alert alert-danger alert-dismissible fade show" role="alert">${displayError}<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>`)
                                })
                            }
                        })                        
                    }
                });
            }

        });

        $(".deleteClientBilling").on('click', function (el) {
            el.preventDefault();

            let form = new FormData,
                client_billing_uuid = $(this).data('clientBillingUuid'),
                client_id = $(this).data('clientId');
            
            form.set('client_billing_uuid', client_billing_uuid);
            form.set('client_id', client_id);
            form.set('action', 'delete_client_billing_ajax');

            $.ajax({
                type: 'POST',
                url: aaAjax.url,
                data: form,
                processData: false,
                contentType: false,
            }).done((response) => {
                // if (response.response.status == 200 && response.response.redirect) {
                //     window.location.replace(response.response.redirect);
                // }
                if (response.success) {
                    let deleteElement = "#" + client_billing_uuid;
                    $(deleteElement).remove();
                }
            }).fail((response) => {
                console.log("Error:");
                console.log(response);
            });
        });

        $(document).on('change', '#birthday', function () {
            let DOB = new Date($(this)[0].value + " 12:00");
            let diff = Date.now() - DOB;
            let ageDiff = new Date(diff);

            if (Math.abs(ageDiff.getUTCFullYear() - 1970) < 18) {
                $('#isMinor').val('1');
                $('.signature-text').each(function () {
                    $(this).html('Signature of Parent or Guardian (Participant is under 18 years of age)')
                });
            }
        });

        $(document).on('click', '#add-card-btn', function (event) {
            event.preventDefault();
            const container = document.getElementById('add-card-container');
            if (!container.classList.contains('hide')) {
                
                $("#add-card-container :input").val('');
                $("#add-card-container :input").removeClass('is-valid');
                $("#add-card-container :input").attr("disabled", true);

            } else {
                $("#add-card-container :input").attr("disabled", false);
                $(".payment-method").each(function (i, e) {
                    e.classList.remove("preferred-method");
                });
                $("#client_billing_uuid").val("");
            }
            container.classList.toggle('hide');
        });

        $(document).on("click", ".payment-method", function (event) {
            event.preventDefault();
            const clickedElement = document.getElementById($(this).attr("id"));
            const cbu = $("#client_billing_uuid").attr('value');

            if (clickedElement.id === cbu) {
                $("#client_billing_uuid").val("");
            } else {
                $("#client_billing_uuid").val(clickedElement.id);
            }

            $(".payment-method").each(function (index, element) {
                if (element.id == clickedElement.id) {
                    !element.classList.contains("preferred-method") ? element.classList.add("preferred-method") : element.classList.remove("preferred-method")
                } else {
                    element.classList.remove("preferred-method");
                }
            });
            
            const container = document.getElementById('add-card-container');
            if (!container.classList.contains('hide')) {
                container.classList.add('hide');

                $("#add-card-container :input").val('');
                $("#add-card-container :input").removeClass('is-valid');
                $("#add-card-container :input").attr("disabled", true);
            }
        })
    });
})(jQuery);