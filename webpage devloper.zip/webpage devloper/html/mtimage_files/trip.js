(function ($) {

    'use strict';

    jQuery(function () {
        $('.delete-client-document').on('click', function (element) {

            let formHash = element.currentTarget.dataset.formId,
                form = document.getElementById(formHash),
                formData = new FormData(form);

            $(document.body).append("<div id='submitting'></div>")

            $.ajax({
                type: 'POST',
                url: aaAjax.url,
                data: formData,
                processData: false,
                contentType: false,
            }).done((response) => {
                if (response.success) {
                    window.location.reload();
                }
                $(document.body).remove("#submitting");
            }).fail((response) => {
                console.log("Error: ");
                console.log(response);
                $(document.body).remove("#submitting");

            });

        });

        $('#clientDocument').on('change', function (el) {
            if (document.getElementById("clientDocument").files.length !== 0 && document.getElementById("clientDocument").files[0].size > 1000000) {
                alert("File size too big. Please upload smaller file.");
                document.getElementById("clientDocument").value = "";
            }
        })

        $('#submitClientDocument').on("click", function (element) {
            if (!document.getElementById('document_type_id').value) {
                return alert("Please select document type");
            }

            if (document.getElementById("clientDocument").files.length !== 0) {
                let form = document.getElementById('new-client-document'),
                    formData = new FormData(form),
                    file = document.getElementById("clientDocument").files[0];
                
                formData.append('client_document', file);

                $(document.body).append("<div id='submitting'></div>")

                $.ajax({
                    type: 'POST',
                    url: aaAjax.url,
                    data: formData,
                    processData: false,
                    contentType: false,
                }).done((response) => {
                    
                    if (response.response && response.response.success) {
                        window.location.reload();
                    }

                    if (response.response && response.response.type == 'error') {
                        alert(response.message);
                    }

                    // $(document.body).remove("#submitting");
                    document.querySelector("#submitting").remove();
                }).fail((response) => {
                    console.log("Error: ");
                    console.log(response);
                    // $(document.body).remove("#submitting");
                    document.querySelector("#submitting").remove();
                });
            } else {
                alert("Please upload file.");
            }
        })
    });
})(jQuery);