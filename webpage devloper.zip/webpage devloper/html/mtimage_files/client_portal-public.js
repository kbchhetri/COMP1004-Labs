(function( $ ) {
	'use strict';

	$(".add-loading").on("click", function () {
		$(document.body).append("<div id='submitting'></div>");
	})

	jQuery(function () {

		$('.datePicker').each(function () {
			$(this).datepicker({
				dateFormat: 'yy-mm-dd',
				changeMonth: true,
				changeYear: true,
				yearRange: '1918:2030'
			});
		});

		$(document).on('click', '.rent-item', function (e) {

			e.preventDefault();
			let uuid = $(this).data('gear-uuid');
			let hiddenInput = $('#' + uuid);
			let price = hiddenInput.data('price');
			if (hiddenInput.is(':disabled')) {
				hiddenInput.prop('disabled', false);
				$(this).removeClass('btn-primary');
				$(this).addClass('btn-success');
				$(this).html('<i class="far fa-check-circle"></i> In Rental Basket');
			} else {
				hiddenInput.prop('disabled', true);
				$(this).addClass('btn-primary');
				$(this).removeClass('btn-success');
				$(this).html('<i class="fas fa-list-alt fa-fw fa-btn" aria-hidden="true"></i>Rent It For $' + price);
			}
			
		});

		let notifications = client_portal_notifications;

		if (notifications && notifications.success) {

			if (Array.isArray(notifications.success)) {
				notifications.success.forEach(function (message) {
					jQuery('#clientPortalNotifications').append('<div class="alert alert-primary" role="alert">' + message + '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div >');
				})
			} else {
				jQuery('#clientPortalNotifications').append('<div class="alert alert-primary" role="alert">' + notifications.success + '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div >');
			}
			
		} else if (notifications && notifications.error) {

			if (Array.isArray(notifications.error)) {
				notifications.error.forEach(function (message) {
					jQuery('#clientPortalNotifications').append('<div class="alert alert-danger" role="alert">' + message + '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div >');
				});
			} else {
				jQuery('#clientPortalNotifications').append('<div class="alert alert-danger" role="alert">' + notifications.error + '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div >');

			}
			
		}

		if (cartCount.count && cartCount.count > 0) {
			$('#purchase-gear-cart-count').html(cartCount.count);
		}
	});

})(jQuery);


function handlePost(url, data) {

	jQuery.ajax({
	    url: url,
	    method: 'POST',
	    data: data,
	    success: function(response){
	    	if(response.success) {
	    		location.reload();
	    	}
	    }
	  });

}


